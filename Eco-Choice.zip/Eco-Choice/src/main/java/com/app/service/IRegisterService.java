package com.app.service;

import com.app.dto.Person;

public interface IRegisterService {

	String addPerson(Person person);

}
